
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <random>
#include <chrono>
//Needed for Sleep function
#include <windows.h>

class JobTimeEstimator {


public:

    static double estimateJobTime(int jobType);

};



